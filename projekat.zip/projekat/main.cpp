// Autor: Nedeljko Tesanovic
// Opis: Testiranje dubine, Uklanjanje lica, Transformacije, Prostori i Projekcije

#define _CRT_SECURE_NO_WARNINGS
 
#include <iostream>
#include <fstream>
#include <sstream>

#include <GL/glew.h> 
#include <GLFW/glfw3.h>

//GLM biblioteke
#include <glm/glm.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <glm/gtc/matrix_transform.hpp>
#define STB_IMAGE_IMPLEMENTATION 
#include "stb_image.h"

unsigned int compileShader(GLenum type, const char* source);
unsigned int createShader(const char* vsSource, const char* fsSource);
static unsigned loadImageToTexture(const char* filePath);

int main(void)
{

   
    if (!glfwInit())
    {
        std::cout<<"GLFW Biblioteka se nije ucitala! :(\n";
        return 1;
    }


    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

    GLFWwindow* window;
    unsigned int wWidth = 500;
    unsigned int wHeight = 500;
    const char wTitle[] = "Galerija";
    window = glfwCreateWindow(wWidth, wHeight, wTitle, NULL, NULL);
    
    if (window == NULL)
    {
        std::cout << "Prozor nije napravljen! :(\n";
        glfwTerminate();
        return 2;
    }
    
    glfwMakeContextCurrent(window);

    
    if (glewInit() != GLEW_OK)
    {
        std::cout << "GLEW nije mogao da se ucita! :'(\n";
        return 3;
    }

    // ++++++++++++++++++++++++++++++++++++++++++++++++++++++ PROMJENLJIVE I BAFERI +++++++++++++++++++++++++++++++++++++++++++++++++

    unsigned int unifiedShader = createShader("basic.vert", "basic.frag");
    unsigned int doorShader = createShader("door.vert", "door.frag");
    unsigned int textShader = createShader("text.vert", "text.frag");

    float vertices[] =
    {
        //X    Y    Z       R    G    B    A
        -4.0, 0.0, -2.99,   1.0, 0.0, 0.0, 0.0, //Crveni trougao
        -2.0, 0.0, -2.99,   1.0, 0.0, 0.0, 0.0,
        -4.0, 3.0, -2.99,   1.0, 0.0, 0.0, 0.0,

        -4.0, 3.0, -2.99,   1.0, 0.0, 0.0, 0.0,
        -2.0, 0.0, -2.99,   1.0, 0.0, 0.0, 0.0,
        -2.0, 3.0, -2.99,   1.0, 0.0, 0.0, 0.0,

        -1.0,1.0,-2.99, 0.5, 1.0, 0.0, 0.0,
         1.5,1.0,-2.99, 0.5, 1.0, 0.0, 0.0,
         -1.0,2.5,-2.99, 0.5, 1.0, 0.0, 0.0,

         -1.0,2.5,-2.99, 0.5, 1.0, 0.0, 0.0,
         1.5,1.0,-2.99, 0.5, 1.0, 0.0, 0.0,
         1.5,2.5,-2.99, 0.5, 1.0, 0.0, 0.0,

         2.5,0.0,-2.99, 1.0, 0.0, 1.0, 0.0,
         4.5,0.0,-2.99, 1.0, 0.0, 1.0, 0.0,
         2.5,2.0,-2.99, 1.0, 0.0, 1.0, 0.0,

         2.5,2.0,-2.99, 1.0, 0.0, 1.0, 0.0,
         4.5,0.0,-2.99, 1.0, 0.0, 1.0, 0.0,
         4.5,2.0,-2.99, 1.0, 0.0, 1.0, 0.0,

         -4.99, 0.0,  2.5, 0.6, 0.8, 1.0, 0.0,
         -4.99, 0.0, -2.5, 0.6, 0.8, 1.0, 0.0,
         -4.99, 4.0,  2.5, 0.6, 0.8, 1.0, 0.0,

         -4.99, 4.0,  2.5, 0.6, 0.8, 1.0, 0.0,
         -4.99, 0.0, -2.5, 0.6, 0.8, 1.0, 0.0,
         -4.99, 4.0,  -2.5, 0.6, 0.8, 1.0, 0.0,

         -3.0, 0.0, 2.99, 1.0,1.0,1.0,1.0,
         -4.0, 0.0, 2.99, 1.0,1.0,1.0,1.0,
         -4.0, 4.5, 2.99, 1.0,1.0,1.0,1.0,

         -3.0, 0.0, 2.99, 1.0,1.0,1.0,1.0,
         -4.0, 4.5, 2.99, 1.0,1.0,1.0,1.0,
         -3.0, 4.0, 2.99, 1.0,1.0,1.0,1.0,

         -2.0, 0.0, 2.99, 0.0,0.0,0.0,1.0,
         -2.9, 0.0, 2.99, 0.0,0.0,0.0,1.0,
         -2.9, 3.9, 2.99, 0.0,0.0,0.0,1.0,

         -2.0, 0.0, 2.99, 0.0,0.0,0.0,1.0,
         -2.9, 3.9, 2.99, 0.0,0.0,0.0,1.0,
         -2.0, 3.5, 2.99, 0.0,0.0,0.0,1.0,

         -1.0, 0.0, 2.99, 1.0,1.0,1.0,1.0,
         -1.9, 0.0, 2.99, 1.0,1.0,1.0,1.0,
         -1.9, 3.4, 2.99, 1.0,1.0,1.0,1.0,

         -1.0, 0.0, 2.99, 1.0,1.0,1.0,1.0,
         -1.9, 3.4, 2.99, 1.0,1.0,1.0,1.0,
         -1.0, 3.0, 2.99, 1.0,1.0,1.0,1.0,

         -0.0, 0.0, 2.99, 0.0,0.0,0.0,1.0,
         -0.9, 0.0, 2.99, 0.0,0.0,0.0,1.0,
         -0.9, 2.9, 2.99, 0.0,0.0,0.0,1.0,

         -0.0, 0.0, 2.99, 0.0,0.0,0.0,1.0,
         -0.9, 2.9, 2.99, 0.0,0.0,0.0,1.0,
         -0.0, 2.5, 2.99, 0.0,0.0,0.0,1.0,

          1.0, 0.0, 2.99, 1.0,1.0,1.0,1.0,
          0.1, 0.0, 2.99, 1.0,1.0,1.0,1.0,
          0.1, 2.4, 2.99, 1.0,1.0,1.0,1.0,

          1.0, 0.0, 2.99, 1.0,1.0,1.0,1.0,
          0.1, 2.4, 2.99, 1.0,1.0,1.0,1.0,
          1.0, 2.0, 2.99, 1.0,1.0,1.0,1.0,

          2.0, 0.0, 2.99, 0.0,0.0,0.0,1.0,
          1.1, 0.0, 2.99, 0.0,0.0,0.0,1.0,
          1.1, 1.9, 2.99, 0.0,0.0,0.0,1.0,

          2.0, 0.0, 2.99, 0.0,0.0,0.0,1.0,
          1.1, 1.9, 2.99, 0.0,0.0,0.0,1.0,
          2.0, 1.5, 2.99, 0.0,0.0,0.0,1.0,

          3.0, 0.0, 2.99, 1.0,1.0,1.0,1.0,
          2.1, 0.0, 2.99, 1.0,1.0,1.0,1.0,
          2.1, 1.4, 2.99, 1.0,1.0,1.0,1.0,

          3.0, 0.0, 2.99, 1.0,1.0,1.0,1.0,
          2.1, 1.4, 2.99, 1.0,1.0,1.0,1.0,  
          3.0, 1.0, 2.99, 1.0,1.0,1.0,1.0,

          4.0, 0.0, 2.99, 0.0,0.0,0.0,1.0,
          3.1, 0.0, 2.99, 0.0,0.0,0.0,1.0, 
          3.1, 0.9, 2.99, 0.0,0.0,0.0,1.0,

          4.0, 0.0, 2.99, 0.0,0.0,0.0,1.0,
          3.1, 0.9, 2.99, 0.0,0.0,0.0,1.0,
          4.0, 0.5, 2.99, 0.0,0.0,0.0,1.0,
    };
    unsigned int stride = (3 + 4) * sizeof(float); 
    
    unsigned int VAO;
    glGenVertexArrays(1, &VAO);
    glBindVertexArray(VAO);

    unsigned int VBO;
    glGenBuffers(1, &VBO);
    glBindBuffer(GL_ARRAY_BUFFER, VBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);

    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, stride, (void*)0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, 4, GL_FLOAT, GL_FALSE, stride, (void*)(3 * sizeof(float)));
    glEnableVertexAttribArray(1);

    glBindBuffer(GL_ARRAY_BUFFER, 0);
    glBindVertexArray(0);
    
    //Gallery
    float wallVertices[] = {
        /*5.0, -0.5, -3.0,  1.0, 0.9, 0.8, 0.0,   //desni zid
        5.0, -0.5,  3.0,  1.0, 0.9, 0.8, 0.0,
        5.0,  5.0,  3.0,  1.0, 0.9, 0.8, 0.0,
        
        5.0,  5.0, -3.0,  1.0, 0.9, 0.8, 0.0,
        5.0, -0.5, -3.0,  1.0, 0.9, 0.8, 0.0,
        5.0,  5.0,  3.0,  1.0, 0.9, 0.8, 0.0,*/

        5.0, -0.5, -3.0,  1.0, 0.9, 0.8, 0.0,   //desni zid
        5.0, -0.5, -0.5,  1.0, 0.9, 0.8, 0.0,
        5.0,  5.0, -0.5,  1.0, 0.9, 0.8, 0.0,

        5.0,  5.0, -3.0,  1.0, 0.9, 0.8, 0.0,
        5.0, -0.5, -3.0,  1.0, 0.9, 0.8, 0.0,
        5.0,  5.0, -0.5,  1.0, 0.9, 0.8, 0.0,

        5.0, -0.5,  0.5,  1.0, 0.9, 0.8, 0.0,
        5.0, -0.5,  3.0,  1.0, 0.9, 0.8, 0.0,
        5.0,  5.0,  0.5,  1.0, 0.9, 0.8, 0.0,

        5.0, -0.5,  3.0,  1.0, 0.9, 0.8, 0.0,
        5.0,  5.0,  3.0,  1.0, 0.9, 0.8, 0.0,
        5.0,  5.0,  0.5,  1.0, 0.9, 0.8, 0.0,

        5.0,  1.5, -0.5,  1.0, 0.9, 0.8, 0.0,
        5.0,  1.5,  0.5,  1.0, 0.9, 0.8, 0.0,
        5.0,  5.0, -0.5,  1.0, 0.9, 0.8, 0.0,

        5.0,  1.5,  0.5,  1.0, 0.9, 0.8, 0.0,
        5.0,  5.0,  0.5,  1.0, 0.9, 0.8, 0.0,
        5.0,  5.0, -0.5,  1.0, 0.9, 0.8, 0.0,

       -5.0, -0.5, -3.0,  1.0, 0.9, 0.8, 0.0,   //prednji
        5.0, -0.5, -3.0,  1.0, 0.9, 0.8, 0.0,
        5.0,  5.0, -3.0,  1.0, 0.9, 0.8, 0.0,
        
       -5.0,  5.0, -3.0,  1.0, 0.9, 0.8, 0.0,
       -5.0, -0.5, -3.0,  1.0, 0.9, 0.8, 0.0,
        5.0,  5.0, -3.0,  1.0, 0.9, 0.8, 0.0,
        
       -5.0, -0.5,  3.0,  1.0, 0.9, 0.8, 0.0,   //levi
       -5.0, -0.5, -3.0,  1.0, 0.9, 0.8, 0.0,
       -5.0,  5.0,  3.0,  1.0, 0.9, 0.8, 0.0,

       -5.0, -0.5, -3.0,  1.0, 0.9, 0.8, 0.0,
       -5.0,  5.0, -3.0,  1.0, 0.9, 0.8, 0.0,    
       -5.0,  5.0,  3.0,  1.0, 0.9, 0.8, 0.0,
        
        5.0, -0.5,  3.0,  1.0, 0.9, 0.8, 0.0,   //zadnji
       -5.0, -0.5,  3.0,  1.0, 0.9, 0.8, 0.0,
        5.0,  5.0,  3.0,  1.0, 0.9, 0.8, 0.0,

       -5.0, -0.5,  3.0,  1.0, 0.9, 0.8, 0.0,
       -5.0,  5.0,  3.0,  1.0, 0.9, 0.8, 0.0,
        5.0,  5.0,  3.0,  1.0, 0.9, 0.8, 0.0,

       -5.0,  5.0,  3.0,  1.0, 0.9, 0.8, 0.0,   //krov
       -5.0,  5.0, -3.0,  1.0, 0.9, 0.8, 0.0,
        5.0,  5.0, -3.0,  1.0, 0.9, 0.8, 0.0,

        5.0,  5.0,  3.0,  1.0, 0.9, 0.8, 0.0,
       -5.0,  5.0,  3.0,  1.0, 0.9, 0.8, 0.0,
        5.0,  5.0, -3.0,  1.0, 0.9, 0.8, 0.0
    };

    unsigned int roomVAO;
    glGenVertexArrays(1, &roomVAO);
    glBindVertexArray(roomVAO);

    unsigned int roomVBO;
    glGenBuffers(1, &roomVBO);
    glBindBuffer(GL_ARRAY_BUFFER, roomVBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(wallVertices), wallVertices, GL_STATIC_DRAW);

    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, stride, (void*)0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, 4, GL_FLOAT, GL_FALSE, stride, (void*)(3 * sizeof(float)));
    glEnableVertexAttribArray(1);

    glBindBuffer(GL_ARRAY_BUFFER, 0);
    glBindVertexArray(0);

    //outline
    float outlineVertices[] = {
        4.99, -0.5,  2.99,  0.0, 0.0, 0.0, 0.0,
        4.99,  5.0,  2.99,  0.0, 0.0, 0.0, 0.0,

       -4.99, -0.5, -2.99,  0.0, 0.0, 0.0, 0.0,
       -4.99,  5.0, -2.99,  0.0, 0.0, 0.0, 0.0,

       -4.99, -0.5,  2.99,  0.0, 0.0, 0.0, 0.0,
       -4.99,  5.0,  2.99,  0.0, 0.0, 0.0, 0.0,

        4.99, -0.5, -2.99,  0.0, 0.0, 0.0, 0.0,
        4.99,  5.0, -2.99,  0.0, 0.0, 0.0, 0.0,

        4.99,  4.99,  2.99,  0.0, 0.0, 0.0, 0.0,
       -4.99,  4.99,  2.99,  0.0, 0.0, 0.0, 0.0,

        4.99,  4.99, -2.99,  0.0, 0.0, 0.0, 0.0,
        4.99,  4.99,  2.99,  0.0, 0.0, 0.0, 0.0,

        4.99,  4.99, -2.99,  0.0, 0.0, 0.0, 0.0,
       -4.99,  4.99, -2.99,  0.0, 0.0, 0.0, 0.0,

       -4.99,  4.99, -2.99,  0.0, 0.0, 0.0, 0.0,
       -4.99,  4.99,  2.99,  0.0, 0.0, 0.0, 0.0,


    };
    unsigned int outlineVAO;
    glGenVertexArrays(1, &outlineVAO);
    glBindVertexArray(outlineVAO);

    unsigned int outlineVBO;
    glGenBuffers(1, &outlineVBO);
    glBindBuffer(GL_ARRAY_BUFFER, outlineVBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(outlineVertices), outlineVertices, GL_STATIC_DRAW);

    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, stride, (void*)0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, 4, GL_FLOAT, GL_FALSE, stride, (void*)(3 * sizeof(float)));
    glEnableVertexAttribArray(1);

    glBindBuffer(GL_ARRAY_BUFFER, 0);
    glBindVertexArray(0);


    //vrata
    
    float doorVertices[] = {
        5.0, -0.5,  -0.5,  0.0, 0.0, 0.0, 0.0,
        5.0, -0.5,   0.5,  0.0, 0.0, 0.0, 0.0,
        5.0,  1.5,  -0.5,  0.0, 0.0, 0.0, 0.0,

        5.0, -0.5,   0.5,  0.0, 0.0, 0.0, 0.0,
        5.0,  1.5,   0.5,  0.0, 0.0, 0.0, 0.0,
        5.0,  1.5,  -0.5,  0.0, 0.0, 0.0, 0.0,
    };
    unsigned int doorVAO;
    glGenVertexArrays(1, &doorVAO);
    glBindVertexArray(doorVAO);

    unsigned int doorVBO;
    glGenBuffers(1, &doorVBO);
    glBindBuffer(GL_ARRAY_BUFFER, doorVBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(doorVertices), doorVertices, GL_STATIC_DRAW);

    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, stride, (void*)0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, 4, GL_FLOAT, GL_FALSE, stride, (void*)(3 * sizeof(float)));
    glEnableVertexAttribArray(1);

    glBindBuffer(GL_ARRAY_BUFFER, 0);
    glBindVertexArray(0);


    //text
    unsigned textureText = loadImageToTexture("Index.png"); //Ucitavamo teksturu
    glBindTexture(GL_TEXTURE_2D, textureText); //Podesavamo teksturu
    glGenerateMipmap(GL_TEXTURE_2D); //Generisemo mipmape 
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_BORDER);//S = U = X    GL_REPEAT, GL_CLAMP_TO_EDGE, GL_CLAMP_TO_BORDER
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_BORDER);// T = V = Y
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);   //GL_NEAREST, GL_LINEAR
    glBindTexture(GL_TEXTURE_2D, 0);
    glUseProgram(textShader);
    unsigned uTexLoc = glGetUniformLocation(textShader, "uTex");
    uTexLoc = glGetUniformLocation(textShader, "uTex");
    glUniform1i(uTexLoc, 0); // Indeks teksturne jedinice (sa koje teksture ce se citati boje)
    glUseProgram(0);

    float textVertices[] = {
        // Positions          // Texture Coords
        0.6, 0.95f ,-1.0f,   0.0f, 0.0f, // Bottom-left
        1.0f, 0.95f, -1.0f,   1.0f, 0.0f, // Bottom-right
        1.0f,  1.0f, -1.0f,   1.0f, 1.0f, // Top-right
        0.6, 1.0f, -1.0f,   0.0f, 1.0f  // Top-left
    };

    GLuint textVBO, textVAO;
    glGenVertexArrays(1, &textVAO);
    glGenBuffers(1, &textVBO);

    glBindVertexArray(textVAO);

    glBindBuffer(GL_ARRAY_BUFFER, textVBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(textVertices), textVertices, GL_STATIC_DRAW);


    // ++++++++++++++++++++++++++++++++++++++++++++++++++++++            UNIFORME            +++++++++++++++++++++++++++++++++++++++++++++++++
    //First person kamera
    glm::vec3 cameraPos = glm::vec3(0.0f, 0.0f, 3.0f);
    glm::vec3 cameraFront = glm::vec3(0.0f, 0.0f, -1.0f);
    glm::vec3 cameraUp = glm::vec3(0.0f, 1.0f, 0.0f);

    float yaw = -90.0f;

    glm::vec3 direction;
    direction.x = cos(glm::radians(yaw)); // Note that we convert the angle to radians first
    direction.z = sin(glm::radians(yaw));

    glm::mat4 model = glm::mat4(1.0f); //Matrica transformacija - mat4(1.0f) generise jedinicnu matricu
    unsigned int modelLoc = glGetUniformLocation(unifiedShader, "uM");
    
    glm::mat4 view; //Matrica pogleda (kamere)
    view = glm::lookAt(cameraPos, cameraPos + cameraFront, cameraUp); // lookAt(Gdje je kamera, u sta kamera gleda, jedinicni vektor pozitivne Y ose svijeta  - ovo rotira kameru)
    unsigned int viewLoc = glGetUniformLocation(unifiedShader, "uV");
    
    
    glm::mat4 projectionP = glm::perspective(glm::radians(90.0f), (float)wWidth / (float)wHeight, 0.1f, 100.0f); //Matrica perspektivne projekcije (FOV, Aspect Ratio, prednja ravan, zadnja ravan)
    glm::mat4 projectionO = glm::ortho(-1.0f, 1.0f, -1.0f, 1.0f, 0.1f, 100.0f); //Matrica ortogonalne projekcije (Lijeva, desna, donja, gornja, prednja i zadnja ravan)
    unsigned int projectionLoc = glGetUniformLocation(unifiedShader, "uP");

    //transformacija vrata
    glUseProgram(doorShader);

  
    unsigned int viewLoc1 = glGetUniformLocation(doorShader, "uV1");


    unsigned int projectionLoc1 = glGetUniformLocation(doorShader, "uP1");
    glm::mat4 trans = glm::mat4(1.0f);
    unsigned int transLoc = glGetUniformLocation(doorShader, "transform");
    glUniformMatrix4fv(transLoc, 1, GL_FALSE, glm::value_ptr(trans));

    // ++++++++++++++++++++++++++++++++++++++++++++++++++++++ RENDER LOOP - PETLJA ZA CRTANJE +++++++++++++++++++++++++++++++++++++++++++++++++
    glUseProgram(unifiedShader); //Slanje default vrijednosti uniformi
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model)); //(Adresa matrice, broj matrica koje saljemo, da li treba da se transponuju, pokazivac do matrica)
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projectionLoc, 1, GL_FALSE, glm::value_ptr(projectionP));
    glBindVertexArray(VAO);

    glUseProgram(doorShader); //Slanje default vrijednosti uniformi
    glUniformMatrix4fv(viewLoc1, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projectionLoc1, 1, GL_FALSE, glm::value_ptr(projectionP));
    glBindVertexArray(doorVAO);
    
    glClearColor(0.5, 0.5, 0.5, 1.0);
    glCullFace(GL_BACK);//Biranje lica koje ce se eliminisati (tek nakon sto ukljucimo Face Culling)
    glEnable(GL_DEPTH_TEST);
    
    int doorTimer = 0;
    int opening = 0;
    bool opened = false;
    float fov = 90;

    while (!glfwWindowShouldClose(window))
    {
        glUseProgram(unifiedShader);
        //first person kamera movement
        const float cameraSpeed = 0.05f;
        if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
            cameraPos += cameraSpeed * cameraFront;
        if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
            cameraPos -= cameraSpeed * cameraFront;
        if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)
            cameraPos -= glm::normalize(glm::cross(cameraFront, cameraUp)) * cameraSpeed;
        if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)
            cameraPos += glm::normalize(glm::cross(cameraFront, cameraUp)) * cameraSpeed;
        
        if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS)
            yaw -= 1.0f;
        if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS)
            yaw += 1.0f;

        glm::vec3 direction;
        direction.x = cos(glm::radians(yaw)) * cos(glm::radians(0.0f));
        direction.y = sin(glm::radians(0.0f));
        direction.z = sin(glm::radians(yaw)) * cos(glm::radians(0.0f));
        cameraFront = glm::normalize(direction);

        view = glm::lookAt(cameraPos, cameraPos + cameraFront, cameraUp);
        glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
        glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
        glUseProgram(doorShader);
        glUniformMatrix4fv(viewLoc1, 1, GL_FALSE, glm::value_ptr(view));
        glUniformMatrix4fv(transLoc, 1, GL_FALSE, glm::value_ptr(trans));
        glUseProgram(unifiedShader);
        //vrata
        if (glfwGetKey(window, GLFW_KEY_SPACE) == GLFW_PRESS && opening==0) {
            
            opening = 1;
        }

        if (opening == 1) {
            if (opened == false) {
                trans = glm::translate(trans, glm::vec3(5.0f, 0.0f, 0.5f));
                trans = glm::rotate(trans, glm::radians(-3.0f), glm::vec3(0.0, 1.0, 0.0));
                trans = glm::translate(trans, glm::vec3(-5.0f, 0.0f, -0.5f));
            }
            else {
                trans = glm::translate(trans, glm::vec3(5.0f, 0.0f, 0.5f));
                trans = glm::rotate(trans, glm::radians(3.0f), glm::vec3(0.0, 1.0, 0.0));
                trans = glm::translate(trans, glm::vec3(-5.0f, 0.0f, -0.5f));
            }
            doorTimer += 1;
            if (doorTimer == 30) {
                opening = 0;
                doorTimer = 0;
                opened = !opened;
            }
        }

        if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
        {
            glfwSetWindowShouldClose(window, GL_TRUE);
        }

        //Testiranje dubine
        if (glfwGetKey(window, GLFW_KEY_1) == GLFW_PRESS)
        {
            glEnable(GL_DEPTH_TEST); //Ukljucivanje testiranja Z bafera
        }
        if (glfwGetKey(window, GLFW_KEY_2) == GLFW_PRESS)
        {
            glDisable(GL_DEPTH_TEST);
        }

        //Odstranjivanje lica (Prethodno smo podesili koje lice uklanjamo sa glCullFace)
        if (glfwGetKey(window, GLFW_KEY_3) == GLFW_PRESS)
        {
            glEnable(GL_CULL_FACE);
        }
        if (glfwGetKey(window, GLFW_KEY_4) == GLFW_PRESS)
        {
            glDisable(GL_CULL_FACE);
        }
        //zoom
        if (glfwGetKey(window, GLFW_KEY_X) == GLFW_PRESS) {
            fov += 1;
            if (fov > 90.0f)
                fov = 90.0f;
        }
        if (glfwGetKey(window, GLFW_KEY_Z) == GLFW_PRESS) {
            fov -= 1;
            if (fov < 1.0f)
                fov = 1.0f;
        }
        glm::mat4 projectionP = glm::perspective(glm::radians(fov), (float)wWidth / (float)wHeight, 0.1f, 100.0f);
        glUniformMatrix4fv(projectionLoc, 1, GL_FALSE, glm::value_ptr(projectionP));
        glUseProgram(doorShader);
        glUniformMatrix4fv(projectionLoc1, 1, GL_FALSE, glm::value_ptr(projectionP));
        glUseProgram(unifiedShader);
        //Mijenjanje projekcija
        /*if (glfwGetKey(window, GLFW_KEY_P) == GLFW_PRESS)
        {
            glUniformMatrix4fv(projectionLoc, 1, GL_FALSE, glm::value_ptr(projectionP));
        }
        if (glfwGetKey(window, GLFW_KEY_O) == GLFW_PRESS)
        {
            glUniformMatrix4fv(projectionLoc, 1, GL_FALSE, glm::value_ptr(projectionO));
        }*/
        //Transformisanje trouglova
        /*if (glfwGetKey(window, GLFW_KEY_X) == GLFW_PRESS)
        {
            model = glm::translate(model, glm::vec3(-0.01, 0.0, 0.0)); //Pomjeranje (Matrica transformacije, pomjeraj po XYZ)
            //model = glm::rotate(model, glm::radians(-0.5f), glm::vec3(0.0f, 1.0f, 0.0f)); //Rotiranje (Matrica transformacije, ugao rotacije u radijanima, osa rotacije)
            //model = glm::scale(model, glm::vec3(0.99, 1.0, 1.0)); //Skaliranje (Matrica transformacije, skaliranje po XYZ)
            glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
        }
        if (glfwGetKey(window, GLFW_KEY_Z) == GLFW_PRESS)
        {
            model = glm::translate(model, glm::vec3(0.01, 0.0, 0.0));
            //model = glm::rotate(model, glm::radians(0.5f), glm::vec3(0.0f, 1.0f, 0.0f));
            //model = glm::scale(model, glm::vec3(1.1, 1.0, 1.0));
            glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
        }
        */
        

        //Text


        glBindVertexArray(textVAO);

        glBindBuffer(GL_ARRAY_BUFFER, textVBO);
        glBufferData(GL_ARRAY_BUFFER, sizeof(textVertices), textVertices, GL_STATIC_DRAW);



        // Vertex position
        glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 5 * sizeof(float), (void*)0);
        glEnableVertexAttribArray(0);

        // Texture coordinates
        glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 5 * sizeof(float), (void*)(3 * sizeof(float)));
        glEnableVertexAttribArray(1);
        glUseProgram(textShader);
        glBindVertexArray(textVAO);

        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, textureText);

        glDrawArrays(GL_TRIANGLE_FAN, 0, 4);

        glBindTexture(GL_TEXTURE_2D, 0);
        glBindVertexArray(0);


        glUseProgram(unifiedShader);
        glBindVertexArray(VAO);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT); //Osvjezavamo i Z bafer i bafer boje
        glDrawArrays(GL_TRIANGLES, 0, 72);

        glBindVertexArray(roomVAO);
        glDrawArrays(GL_TRIANGLES, 0, 42);

        glBindVertexArray(outlineVAO);
        glDrawArrays(GL_LINES, 0, 16);

        glUseProgram(doorShader);
        glBindVertexArray(doorVAO);
        glDrawArrays(GL_TRIANGLES, 0, 6);

        

        glfwSwapBuffers(window);
        glfwPollEvents();
    }

    // ++++++++++++++++++++++++++++++++++++++++++++++++++++++ POSPREMANJE +++++++++++++++++++++++++++++++++++++++++++++++++


    glDeleteBuffers(1, &VBO);
    glDeleteVertexArrays(1, &VAO);
    glDeleteBuffers(1, &roomVBO);
    glDeleteVertexArrays(1, &roomVAO);
    glDeleteProgram(unifiedShader);

    glfwTerminate();
    return 0;
}

unsigned int compileShader(GLenum type, const char* source)
{
    std::string content = "";
    std::ifstream file(source);
    std::stringstream ss;
    if (file.is_open())
    {
        ss << file.rdbuf();
        file.close();
        std::cout << "Uspjesno procitao fajl sa putanje \"" << source << "\"!" << std::endl;
    }
    else {
        ss << "";
        std::cout << "Greska pri citanju fajla sa putanje \"" << source << "\"!" << std::endl;
    }
     std::string temp = ss.str();
     const char* sourceCode = temp.c_str();

    int shader = glCreateShader(type);
    
    int success;
    char infoLog[512];
    glShaderSource(shader, 1, &sourceCode, NULL);
    glCompileShader(shader);

    glGetShaderiv(shader, GL_COMPILE_STATUS, &success);
    if (success == GL_FALSE)
    {
        glGetShaderInfoLog(shader, 512, NULL, infoLog);
        if (type == GL_VERTEX_SHADER)
            printf("VERTEX");
        else if (type == GL_FRAGMENT_SHADER)
            printf("FRAGMENT");
        printf(" sejder ima gresku! Greska: \n");
        printf(infoLog);
    }
    return shader;
}
unsigned int createShader(const char* vsSource, const char* fsSource)
{
    unsigned int program;
    unsigned int vertexShader;
    unsigned int fragmentShader;

    program = glCreateProgram();

    vertexShader = compileShader(GL_VERTEX_SHADER, vsSource);
    fragmentShader = compileShader(GL_FRAGMENT_SHADER, fsSource);

    glAttachShader(program, vertexShader);
    glAttachShader(program, fragmentShader);

    glLinkProgram(program);
    glValidateProgram(program);

    int success;
    char infoLog[512];
    glGetProgramiv(program, GL_VALIDATE_STATUS, &success);
    if (success == GL_FALSE)
    {
        glGetShaderInfoLog(program, 512, NULL, infoLog);
        std::cout << "Objedinjeni sejder ima gresku! Greska: \n";
        std::cout << infoLog << std::endl;
    }

    glDetachShader(program, vertexShader);
    glDeleteShader(vertexShader);
    glDetachShader(program, fragmentShader);
    glDeleteShader(fragmentShader);

    return program;
}
static unsigned loadImageToTexture(const char* filePath) {
    int TextureWidth;
    int TextureHeight;
    int TextureChannels;
    unsigned char* ImageData = stbi_load(filePath, &TextureWidth, &TextureHeight, &TextureChannels, 0);
    if (ImageData != NULL)
    {
        //Slike se osnovno ucitavaju naopako pa se moraju ispraviti da budu uspravne
        stbi__vertical_flip(ImageData, TextureWidth, TextureHeight, TextureChannels);

        // Provjerava koji je format boja ucitane slike
        GLint InternalFormat = -1;
        switch (TextureChannels) {
        case 1: InternalFormat = GL_RED; break;
        case 2: InternalFormat = GL_RG; break;
        case 3: InternalFormat = GL_RGB; break;
        case 4: InternalFormat = GL_RGBA; break;
        default: InternalFormat = GL_RGB; break;
        }

        unsigned int Texture;
        glGenTextures(1, &Texture);
        glBindTexture(GL_TEXTURE_2D, Texture);
        glTexImage2D(GL_TEXTURE_2D, 0, InternalFormat, TextureWidth, TextureHeight, 0, InternalFormat, GL_UNSIGNED_BYTE, ImageData);
        glBindTexture(GL_TEXTURE_2D, 0);
        // oslobadjanje memorije zauzete sa stbi_load posto vise nije potrebna
        stbi_image_free(ImageData);
        return Texture;
    }
    else
    {
        std::cout << "Textura nije ucitana! Putanja texture: " << filePath << std::endl;
        stbi_image_free(ImageData);
        return 0;
    }
}